import io
import os, codecs

import html2text
import unicodecsv as csv
import nltk
from bs4 import BeautifulSoup
from collections import Counter
from nltk.tokenize import RegexpTokenizer
from tabulate import tabulate

html_files = []
# traverse the directory to list all the html files in the directory
for root, dirs, files in os.walk(os.path.abspath('./articles')):
    for file in files:
        if file.endswith('.html'):
            filepath = os.path.join(root, file)
            html_files.append(filepath)

#html_files = html_files[:10]

tokens = []
# process each html file
for idx, file in enumerate(html_files):
    print('{} of {}. Processing {}'.format(idx+1, len(html_files), file))
    print('=' * 30)

    # get text only from each file -> remove all tags
    h = html2text.HTML2Text()
    h.ignore_links = True
    text = h.handle(u' '.join([line.strip() for line in io.open(file, "r", encoding="utf-8").readlines()]))

    # get all words from text by splitting by whitespace
    for word in text.split():
        if word.isalnum():
            tokens.append(word.lower())

# create bigrams from tokens
bigrams = list(nltk.bigrams(tokens))

# count the frequency for each word
counts = {}
for token in tokens:
    counts.setdefault(token, 0)
    counts[token] += 1

# count the frequency for each bigram
counts2 = {}
for token in bigrams:
    counts2.setdefault(token, 0)
    counts2[token] += 1

# convert dict to 2d list
table = []
for count in counts:
    table.append([count, counts[count]])

table2 = []
for count2 in counts2:
    table2.append([count2, counts2[count2]])

# sort list by freq (2nd column)
table = sorted(table, key=lambda x:x[1], reverse=True)
table2 = sorted(table2, key=lambda x:x[1], reverse=True)

# add columns :
# - rank (3rd col)
# - prob (4th col)
# - c (5th col)
tmp_table=[]
for idx, row in enumerate(table):
    rank = idx + 1
    prob = float(row[1]) / len(tokens)
    c = rank * prob
    tmp_table.append(row + [rank, prob, c])

tmp_table2=[]
for idx2, row2 in enumerate(table2):
    rank = idx2 + 1
    prob = float(row2[1]) / len(bigrams)
    c = rank * prob
    row2[0] = ', '.join(row2[0])
    tmp_table2.append(row2 + [rank, prob, c])

# print the resulting table
# print tabulate(tmp_table, headers=["word", "frequency", "rank"]) + "\n\n"
# print tabulate(tmp_table2, headers=["bigram", "frequency", "rank"])

# write the output to csv file
out_file = os.path.join(os.getcwd(), '4_1-rank_freq.csv')
with open(out_file, "wb") as f:
    writer = csv.writer(f)
    writer.writerow(["word", "frequency", "rank", "prob", "c"])
    writer.writerows(tmp_table)

out_file2 = os.path.join(os.getcwd(), '4_1-rank_freq_bigram.csv')
with open(out_file2, "wb") as f2:
    writer = csv.writer(f2)
    writer.writerow(["bigram", "frequency", "rank", "prob", "c"])
    writer.writerows(tmp_table2)

print('number of html files that are processed {}'.format(len(html_files)))
